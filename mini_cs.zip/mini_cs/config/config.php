<?php
$rConfig = Array(
    "video_port" => 18000,
    "segments_sling" => 10,
);
