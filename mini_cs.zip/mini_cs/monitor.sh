#!/bin/bash
while true
#do
	php /home/wvtohls/monitor.php
	echo "Comando executado"
#	sleep 15
#done
